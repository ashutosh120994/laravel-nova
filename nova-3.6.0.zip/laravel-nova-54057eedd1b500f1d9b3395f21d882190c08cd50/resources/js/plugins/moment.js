import moment from 'moment-timezone'

/**
 * Set Moment as a global so you don't have to import it
 */
window.moment = moment
